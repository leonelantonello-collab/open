# OpenFluxo — Next.js + Tailwind + Partículas (react-tsparticles)

## Rodar localmente
```bash
npm install
npm run dev
# abre http://localhost:3000
```

## Build de produção
```bash
npm run build
npm start
```

## Customização rápida
- Cores e tema: `tailwind.config.js`
- Estilos globais (glass, gradiente): `styles/globals.css`
- Partículas: editar `options` em `pages/index.jsx`

## Deploy
- Vercel (recomendado): conectar o repositório e `npm run build` automatico.
- Netlify: adaptação padrão Next (usando Netlify Next runtime).
- VPS: `npm run build` + `npm start` (com PM2) por trás de Nginx.
