/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pages/**/*.{js,jsx,ts,tsx}", "./components/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter","ui-sans-serif","system-ui"],
        display: ["Space Grotesk","Inter","system-ui"],
      },
      colors: {
        brand: { purple: "#7C3AED", cyan: "#06B6D4", dark: "#0B1020" },
      },
      boxShadow: { glass: "0 8px 30px rgba(0,0,0,.35)" }
    }
  },
  plugins: []
};
