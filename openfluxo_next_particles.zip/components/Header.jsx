export default function Header(){
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 backdrop-blur bg-brand-dark/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
        <a href="#hero" className="flex items-center gap-3 group">
          <img src="/logo.svg" alt="OpenFluxo" className="h-9 w-9" />
          <div>
            <div className="font-display text-lg leading-tight">OpenFluxo</div>
            <div className="text-xs text-white/60 -mt-1">Automação & IA para Clínicas</div>
          </div>
        </a>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <a href="#servicos" className="hover:text-brand-cyan">Serviços</a>
          <a href="#planos" className="hover:text-brand-cyan">Planos</a>
          <a href="#faq" className="hover:text-brand-cyan">FAQ</a>
          <a href="#contato" className="hover:text-brand-cyan">Contato</a>
        </nav>
        <a href="https://wa.me/5511944672225" target="_blank" className="px-4 py-2 rounded-xl bg-white text-brand-dark font-semibold shadow hover:opacity-90">WhatsApp</a>
      </div>
    </header>
  )
}
