export default function Footer(){
  return (
    <footer className="border-t border-white/10 py-10 text-white/70">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 grid md:grid-cols-4 gap-8">
        <div>
          <div className="font-display text-xl text-white">OpenFluxo</div>
          <p className="mt-2">Automação & IA especializada para clínicas.</p>
        </div>
        <div>
          <div className="text-white font-semibold">Navegação</div>
          <ul className="mt-2 space-y-1">
            <li><a href="#servicos" className="hover:text-white">Serviços</a></li>
            <li><a href="#planos" className="hover:text-white">Planos</a></li>
            <li><a href="#faq" className="hover:text-white">FAQ</a></li>
            <li><a href="#contato" className="hover:text-white">Contato</a></li>
          </ul>
        </div>
        <div>
          <div className="text-white font-semibold">Legal</div>
          <ul className="mt-2 space-y-1">
            <li><a href="#" className="hover:text-white">Política de Privacidade</a></li>
            <li><a href="#" className="hover:text-white">Termos de Uso</a></li>
          </ul>
        </div>
        <div>
          <div className="text-white font-semibold">Fale conosco</div>
          <ul className="mt-2 space-y-1">
            <li><a href="mailto:openfluxoai@gmail.com" className="hover:text-white">openfluxoai@gmail.com</a></li>
            <li><a href="https://wa.me/5511944672225" target="_blank" className="hover:text-white">WhatsApp: (11) 94467-2225</a></li>
          </ul>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-8 mt-8 text-xs text-white/50">© {new Date().getFullYear()} OpenFluxo Tecnologia LTDA.</div>
    </footer>
  )
}
