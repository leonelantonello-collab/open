import Head from 'next/head'
import { useCallback } from 'react'
import { Particles } from 'react-tsparticles'
import { loadSlim } from 'tsparticles-slim' // smaller bundle alternative
import Header from '@/components/Header'
import Footer from '@/components/Footer'

export default function Home() {
  const particlesInit = useCallback(async (engine) => {
    await loadSlim(engine);
  }, []);

  const options = {
    fullScreen: { enable: false },
    background: { color: 'transparent' },
    detectRetina: true,
    fpsLimit: 60,
    interactivity: {
      events: {
        onHover: { enable: true, mode: ['repulse','bubble'] },
        onClick: { enable: true, mode: ['push'] },
        resize: true
      },
      modes: {
        bubble: { distance: 180, duration: 2, opacity: 1, size: 3 },
        repulse: { distance: 140, duration: 0.4 },
        push: { quantity: 4 },
      }
    },
    particles: {
      number: { value: 90, density: { enable: true, area: 1000 } },
      color: { value: ['#7C3AED', '#06B6D4', '#ffffff'] },
      shape: { type: 'circle' },
      opacity: { value: 0.5, random: { enable: true, minimumValue: 0.3 } },
      size: { value: { min: 1, max: 3 } },
      links: { enable: true, distance: 140, opacity: 0.25, width: 1, color: '#7C3AED' },
      move: { enable: true, speed: 1.0, direction: 'none', outModes: { default: 'bounce' } }
    },
    motion: { reduce: { factor: 2 } },
    pauseOnBlur: true
  };

  return (
    <>
      <Head>
        <title>OpenFluxo — Automação & IA para Clínicas</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <div id="tsparticles" className="fixed inset-0 -z-10">
        <Particles id="tsparticles" init={particlesInit} options={options} />
      </div>
      <Header />
      <main className="text-white">
        <section id="hero" className="relative">
          <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20 lg:py-28 grid lg:grid-cols-2 gap-12">
            <div>
              <h1 className="font-display text-[clamp(2rem,4vw,3.5rem)] leading-tight">
                Agentes de <span className="gradient-text">IA + Automação</span> que lotam a agenda da sua clínica
              </h1>
              <p className="mt-6 text-white/80 max-w-xl">Fluxos no WhatsApp, confirmações automáticas com remarcação, reativação e painéis de métricas.</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href="#planos" className="px-6 py-3 rounded-xl bg-brand-purple hover:bg-brand-purple/90 font-semibold shadow">Ver planos</a>
                <a href="#servicos" className="px-6 py-3 rounded-xl glass font-semibold">Como funciona</a>
              </div>
              <div className="mt-10 flex flex-wrap items-center gap-3 text-sm text-white/70">
                <div className="chip">+30% show rate</div>
                <div className="chip">-40% no‑show</div>
                <div className="chip">Clientes em SP e GO</div>
              </div>
            </div>
            <div className="glass rounded-3xl p-6 min-h-[320px] shadow-glass grid place-items-center">
              <div className="w-full max-w-md text-center">
                <div className="text-white/70">Demonstração</div>
                <p className="text-white/60 text-sm mt-2">Simulador do fluxo de WhatsApp + preview de painel.</p>
                <div className="mt-4 h-56 rounded-2xl glass grid place-items-center">[mockup]</div>
              </div>
            </div>
          </div>
        </section>

        <section id="servicos" className="py-20 border-t border-white/10">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 className="font-display text-3xl lg:text-4xl">Serviços</h2>
            <p className="text-white/70 mt-2 max-w-3xl">Automação, IA e marketing conversam entre si para manter a agenda cheia.</p>
            <div className="mt-10 grid lg:grid-cols-3 gap-6">
              <article className="glass rounded-2xl p-6">
                <h3 className="font-semibold text-xl">Automação</h3>
                <ul className="mt-3 text-white/80 space-y-2 list-disc list-inside">
                  <li>Fluxos WhatsApp: boas‑vindas, captação e pré‑agendamento</li>
                  <li>Confirmações D‑1/H‑3 com remarcação</li>
                  <li>Reativação de inativos/ausentes</li>
                  <li>Agenda Google (1+ profissionais)</li>
                </ul>
              </article>
              <article className="glass rounded-2xl p-6">
                <h3 className="font-semibold text-xl">Agente de IA</h3>
                <ul className="mt-3 text-white/80 space-y-2 list-disc list-inside">
                  <li>FAQ dinâmico e triagem</li>
                  <li>Coleta de dados, tags e roteamento</li>
                  <li>Handoff humano por prioridade</li>
                  <li>Treinável com protocolos</li>
                </ul>
              </article>
              <article className="rounded-2xl p-0 overflow-hidden">
                <div className="white-section p-6 h-full">
                  <h3 className="font-semibold text-xl">Marketing & Tráfego</h3>
                  <p className="mt-3 text-brand-dark/80">Captação com criativos, landing pages e acompanhamento de ROI.</p>
                  <ul className="mt-3 text-brand-dark/90 space-y-2 list-disc list-inside">
                    <li>Campanhas por procedimento e persona</li>
                    <li>Segmentação por tags e funil</li>
                    <li>Relatórios de leads e CPL</li>
                  </ul>
                </div>
              </article>
            </div>
          </div>
        </section>

        <section id="planos" className="py-20 border-t border-white/10">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 className="font-display text-3xl lg:text-4xl">Planos e preços</h2>
            <div className="mt-10 grid md:grid-cols-3 gap-6">
              <article className="glass rounded-2xl p-6">
                <h3 className="font-semibold text-xl">START (Solo)</h3>
                <p className="text-white/70">Setup: R$ 497</p>
                <p className="text-3xl font-display mt-2">R$ 497<span className="text-base font-sans">/mês</span></p>
                <ul className="mt-4 space-y-2 text-white/80 list-disc list-inside">
                  <li>Boas‑vindas e pré‑agendamento</li>
                  <li>Confirmação D‑1/H‑3</li>
                  <li>Agenda (1 profissional)</li>
                </ul>
              </article>
              <article className="glass rounded-2xl p-6 border border-brand-purple/30">
                <h3 className="font-semibold text-xl">PRO (Clínica)</h3>
                <p className="text-white/70">Setup: R$ 997</p>
                <p className="text-3xl font-display mt-2">R$ 997<span className="text-base font-sans">/mês</span></p>
                <ul className="mt-4 space-y-2 text-white/80 list-disc list-inside">
                  <li>Multi‑profissionais + reativação</li>
                  <li>Funil + tags (Sheets/CRM leve)</li>
                  <li>Métricas semanais</li>
                </ul>
              </article>
              <article className="glass rounded-2xl p-6">
                <h3 className="font-semibold text-xl">PREMIUM (Escala)</h3>
                <p className="text-white/70">Setup: R$ 1.497</p>
                <p className="text-3xl font-display mt-2">R$ 1.497<span className="text-base font-sans">/mês</span></p>
                <ul className="mt-4 space-y-2 text-white/80 list-disc list-inside">
                  <li>Automações avançadas</li>
                  <li>Relatórios profundos</li>
                  <li>Suporte prioritário</li>
                </ul>
              </article>
            </div>
          </div>
        </section>

        <section id="faq" className="py-20 border-t border-white/10">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 className="font-display text-3xl lg:text-4xl">FAQ</h2>
            <div className="mt-10 grid md:grid-cols-2 gap-6">
              <article className="glass rounded-2xl p-6">
                <h3 className="font-semibold">O que está incluso e o que é extra?</h3>
                <p className="text-white/70 mt-2">Incluso: setup do plano, fluxos padrão, integrações Google/Sheets, relatórios (e no PRO, 1 otimização/mês). Extra: novas campanhas fora do escopo, integrações não listadas, licenças de terceiros e criativos recorrentes.</p>
              </article>
              <article className="glass rounded-2xl p-6">
                <h3 className="font-semibold">LGPD e opt‑out</h3>
                <p className="text-white/70 mt-2">Base legal adequada, registro de consentimentos e opt‑out em todas as campanhas. Modelos de Privacy Policy e DPA sob demanda.</p>
              </article>
            </div>
          </div>
        </section>

        <section id="contato" className="py-20 border-t border-white/10">
          <div className="max-w-3xl mx-auto px-6 lg:px-8">
            <h2 className="font-display text-3xl lg:text-4xl">Contato</h2>
            <form className="mt-8 grid sm:grid-cols-2 gap-4">
              <input className="glass rounded-xl p-3" placeholder="Nome" />
              <input className="glass rounded-xl p-3" placeholder="WhatsApp" />
              <input className="glass rounded-xl p-3 sm:col-span-2" placeholder="E-mail" />
              <textarea className="glass rounded-xl p-3 sm:col-span-2" rows="5" placeholder="Fale sobre sua clínica e objetivos"></textarea>
              <button type="button" className="sm:col-span-2 px-6 py-3 rounded-xl bg-white text-brand-dark font-semibold">Enviar</button>
            </form>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
